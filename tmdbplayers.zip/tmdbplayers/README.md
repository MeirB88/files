# openplayers For TMDB helper 

TheMovieDb Helper -> Settings -> Players -> Update players from URL, and entering the URL: http://bit.ly/tmdbplayers
